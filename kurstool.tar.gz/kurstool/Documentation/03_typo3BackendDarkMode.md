# TYPO3 v14 Backend Dark Mode — How It Actually Works

## The short answer

TYPO3 sets `data-color-scheme="dark"` on `<html>`. Use `--typo3-*` CSS variables (they use `light-dark()`) in any custom backend HTML. Do **not** use `--bs-*` Bootstrap variables — they never adapt.

---

## Why `--bs-*` variables are broken in dark mode

`backend.css` includes Bootstrap 5's dark-mode overrides:

```css
[data-bs-theme=dark] {
    --bs-body-bg: #1e1e1e;
    --bs-secondary-bg: #333;
    /* … */
}
```

This looks correct, but TYPO3 v14 **never sets `data-bs-theme`**. The dark-mode toggle sets a different attribute.

### What TYPO3 actually does

**PHP side** (`PageRenderer::getDocumentAttributes()`):
```php
if ($colorScheme !== 'auto') {
    $attributes['data-color-scheme'] = $colorScheme;  // 'dark' or 'light'
}
```

**JS side** (`user-settings-manager.js`):
```js
activateColorScheme(scheme) {
    this.setStyleChangingDocumentAttribute('data-color-scheme', scheme);
}
```

So the `<html>` element gets `data-color-scheme="dark"`, and the only CSS that matches it is:

```css
[data-color-scheme=dark] { color-scheme: only dark }
[data-color-scheme=light] { color-scheme: only light }
```

This sets the CSS `color-scheme` property on `<html>`. All descendants inherit it. That is the **entire** mechanism — there are no Bootstrap variable overrides.

### How TYPO3's own components handle dark mode

TYPO3's design system uses the **`light-dark()` CSS function**, which reads the inherited `color-scheme` property:

```css
:root {
    --typo3-surface-bright:              light-dark(#fff, #1a1a1a);
    --typo3-surface-container-high:      light-dark(#e8e8e8, #2e2e2e);
    --typo3-state-default-border-color:  light-dark(#ccc, #555);
    --typo3-text-color-base:             light-dark(#1a1a1a, #d7d7d7);
    /* … */
}
```

When `color-scheme: only dark` is inherited, `light-dark(light-val, dark-val)` returns `dark-val`. That is how every native TYPO3 component adapts — no JavaScript, no class toggling, no `[data-bs-theme]`.

---

## Variable reference for custom backend HTML

Use these `--typo3-*` variables in inline styles or injected `<style>` blocks.

### Layout / surfaces

| Purpose | Variable |
|---|---|
| Page / bright background | `--typo3-surface-bright` |
| Default background | `--typo3-surface-base` |
| Subtle container (alternating row) | `--typo3-surface-container-base` |
| Elevated container (table header) | `--typo3-surface-container-high` |
| Highest elevation | `--typo3-surface-container-highest` |

### Text

| Purpose | Variable |
|---|---|
| Primary body text | `--typo3-text-color-base` |
| Muted / secondary text | `--typo3-text-color-secondary` |
| Info text | `--typo3-text-color-info` |
| Success text | `--typo3-text-color-success` |
| Danger text | `--typo3-text-color-danger` |

### Borders

| Purpose | Variable |
|---|---|
| Default border (tables, cards) | `--typo3-state-default-border-color` |
| Focused / active border | `--typo3-state-default-focus-border-color` |

### Semantic surfaces (badges, callouts)

Each semantic color has a background **and** a paired text variable for contrast.

| Semantic | Background | Text |
|---|---|---|
| Primary (blue) | `--typo3-surface-primary` | `--typo3-surface-primary-text` |
| Secondary (grey) | `--typo3-surface-secondary` | `--typo3-surface-secondary-text` |
| Success (green) | `--typo3-surface-success` | `--typo3-surface-success-text` |
| Danger (red) | `--typo3-surface-danger` | `--typo3-surface-danger-text` |
| Warning (yellow) | `--typo3-surface-warning` | `--typo3-surface-warning-text` |
| Info (teal) | `--typo3-surface-info` | `--typo3-surface-info-text` |
| Notice (dark) | `--typo3-surface-notice` | `--typo3-surface-notice-text` |

For subtle backgrounds (callout boxes), use the container variant:

| Semantic | Subtle background | Subtle text |
|---|---|---|
| Info callout | `--typo3-surface-container-info` | `--typo3-surface-container-info-text` |
| Success callout | `--typo3-surface-container-success` | `--typo3-surface-container-success-text` |
| Danger callout | `--typo3-surface-container-danger` | `--typo3-surface-container-danger-text` |

---

## Where this applies

Any PHP that injects HTML into the TYPO3 backend:
- `fieldWizard` / `fieldInformation` `AbstractNode` subclasses
- `PreviewRenderer` implementations
- Flash messages or custom backend modules that build inline HTML
- ViewHelper output rendered in backend context

---

## What `[data-bs-theme=dark]` is for

The Bootstrap dark-mode block in `backend.css` exists because TYPO3 v14 ships Bootstrap 5 and some third-party components (color pickers, modals) read `data-bs-theme`. TYPO3 does **not** use it for its own theming and does not set it during dark-mode toggle. Treat `--bs-*` variables as light-mode-only constants in the backend.
