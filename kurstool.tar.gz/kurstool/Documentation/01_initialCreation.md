# Kurstool Extbase Plugin — Initial Creation

## Context

Build a TYPO3 v14 Extbase plugin (`EXT:kurstool`, namespace `Taketool\Kurstool\`) that fetches course data from the Kurstool public API and renders it on the frontend. API credentials and cache TTL are configured per-site via a TYPO3 site set. Bootstrap data (locations/targets/categories) and course lists are cached in a dedicated file cache to avoid repeated HTTP calls.

The plugin supports two editor-configurable selection modes:
- **Hierarchy**: pick a locationId → targetId → categoryId (UUIDs, entered manually)
- **Flat**: pick by target name + category name (resolved at runtime from bootstrap data)

---

## File Structure

```
packages/kurstool/
├── ext_localconf.php
├── Classes/
│   ├── Controller/CourseController.php
│   ├── Domain/Dto/
│   │   ├── BootstrapData.php
│   │   ├── Location.php
│   │   ├── Target.php
│   │   ├── Category.php
│   │   ├── Course.php
│   │   └── Instructor.php
│   └── Service/ApiService.php
├── Configuration/
│   ├── FlexForms/CoursePlugin.xml
│   ├── Sets/KurstoolPlugin/
│   │   ├── config.yaml
│   │   ├── settings.definitions.yaml
│   │   └── setup.typoscript
│   ├── TCA/Overrides/tt_content.php
│   └── TypoScript/setup.typoscript
├── Documentation/
│   └── 01_initialCreation.md
└── Resources/Private/
    ├── Language/
    │   ├── locallang.xlf
    │   └── locallang_db.xlf
    ├── Layouts/Default.html
    ├── Partials/Course/Card.html
    └── Templates/Course/Index.html
```

---

## API

- Base URL: site setting `kurstool.apiDomain` (default: `https://gui4.kurstool.de`)
- Auth: request header `X-API-Key: {apiKey}` (site setting `kurstool.apiKey`)
- `GET /api/public/bootstrap` → `{ customer, locations[], targets[], categories[] }`
- `GET /api/public/courses?categoryId=<uuid>&locationId=<uuid>` → courses array

### Data hierarchy
Location → Target (`locationId` FK) → Category (`targetId` FK) → Course (`categoryId` FK)

---

## Architecture

### Domain DTOs (`Classes/Domain/Dto/`)
Plain PHP 8.4 `readonly` classes with `static fromArray(array): self` factories. No Extbase/DB mapping. Serialisation-safe for file cache.

### ApiService (`Classes/Service/ApiService.php`)
- Injected: `RequestFactory`, `CacheManager`
- Cache: `kurstool_api` (VariableFrontend + SimpleFileBackend, groups: all/pages)
- `getBootstrapData()`: cache key `bootstrap_<sanitised_domain>`
- `getCourses()`: cache key `courses_<domain>_<categoryId>_<locationId>`

### CourseController (`Classes/Controller/CourseController.php`)
- Reads site settings via `$this->request->getAttribute('site')->getSettings()`
- Reads FlexForm settings from `$this->settings`
- Flat mode: resolves categoryId/locationId by name-matching bootstrap data

---

## Site Set (`Configuration/Sets/KurstoolPlugin/`)

| Setting | Type | Default |
|---|---|---|
| `kurstool.apiDomain` | string | `https://gui4.kurstool.de` |
| `kurstool.apiKey` | string | `300f4bf8ad7dcccb370c6fd85692d2613b8b06c43d0dea64cb6e06a930121e55` |
| `kurstool.cacheTtl` | int | `3600` |

---

## FlexForm Fields

| Field | Visible when |
|---|---|
| `settings.selectionMode` | always |
| `settings.locationId` | selectionMode = hierarchy |
| `settings.targetId` | selectionMode = hierarchy |
| `settings.categoryId` | selectionMode = hierarchy |
| `settings.flatTargetName` | selectionMode = flat |
| `settings.flatCategoryName` | selectionMode = flat |

---

## Verification

1. `ddev composer dumpautoload`
2. Flush TYPO3 caches
3. Backend → Site Configuration: add set `taketool/kurstool`, set apiKey + apiDomain
4. Create content element "Kurstool: Courses", enter categoryId + locationId (get UUIDs from bootstrap endpoint)
5. Visit frontend — courses render
6. Check `var/cache/data/kurstool_api/` for cached files
7. Test flat mode with target/category names
8. Flush page cache → verify kurstool_api cache also cleared (group `pages`)
