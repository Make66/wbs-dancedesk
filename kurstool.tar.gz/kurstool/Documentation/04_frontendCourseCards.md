# Frontend Course Cards

## Goal

Render each course as a styled Bootstrap 5 card with German date formatting, weekday abbreviations, inline SVG icons, a seats progress bar, availability badges, and a register button. The plugin header comes from the content element's `header` / `subheader` fields. Cards flow in a Bootstrap 5 responsive grid (max 4 per row).

---

## Files changed

| File | Change |
|---|---|
| `Classes/Controller/CourseController.php` | Passes `header`, `headerLayout`, `subheader` from content element; removed debug block |
| `Classes/Domain/Dto/Course.php` | Added `getSeatsPercent(): int` for the progress bar |
| `Classes/ViewHelpers/Format/GermanDateViewHelper.php` | New — formats ISO dates as German date with weekday |
| `Resources/Private/Templates/Course/Index.html` | Full rewrite — plugin header, responsive grid, error alert |
| `Resources/Private/Partials/Course/Card.html` | Full rewrite — Bootstrap card with icons throughout |
| `Resources/Public/Css/kurstool.css` | New — card hover, avatar, chips, seats bar (grid handled by Bootstrap) |

---

## Plugin header

TYPO3 does not render the content element header automatically inside the plugin template — it is usually handled by the TypoScript `lib.stdheader` wrapper around the plugin object. To show it *inside* the plugin's own markup (e.g. above the card grid), it must be read from the content element data and passed to the view explicitly.

```php
// CourseController::indexAction()
$cObj = $this->request->getAttribute('currentContentObject');
$contentData = $cObj?->data ?? [];
$this->view->assignMultiple([
    'header'       => (string)($contentData['header'] ?? ''),
    'headerLayout' => (int)($contentData['header_layout'] ?? 2),
    'subheader'    => (string)($contentData['subheader'] ?? ''),
]);
```

`header_layout` maps to heading level (1–4). Value `100` means "hidden" — the `f:switch` in the template renders nothing in that case.

---

## `GermanDateViewHelper`

Namespace: `Taketool\Kurstool\ViewHelpers\Format`
Usage in Fluid: `{namespace kt=Taketool\Kurstool\ViewHelpers}` then `<kt:format.germanDate date="{course.startsAt}" />`

Arguments:

| Argument | Type | Default | Description |
|---|---|---|---|
| `date` | string | required | ISO date string (e.g. `2025-07-14T18:30:00Z`) |
| `showTime` | bool | `true` | Include time component |

Output examples:

| Input | Output |
|---|---|
| `2025-07-14T18:30:00Z` (current year) | `Mo, 14.07. 18:30 Uhr` |
| `2026-02-03T09:00:00Z` (next year) | `Di, 03.02.2026 09:00 Uhr` |
| `2025-07-14T00:00:00Z` | `Mo, 14.07.` (no time/Uhr when midnight) |
| any, `showTime="0"` | `Mo, 14.07.` |

---

## `Course::getSeatsPercent()`

Added as a public method on the `readonly` class (readonly only restricts promoted constructor properties, not additional methods):

```php
public function getSeatsPercent(): int
{
    if ($this->seatsMax <= 0) return 0;
    return min(100, (int)(($this->seatsCurrent / $this->seatsMax) * 100));
}
```

Fluid accesses it via `{course.seatsPercent}` — the Fluid property resolver calls `getSeatsPercent()` automatically when no public property of that name exists.

---

## Card structure

```
┌─────────────────────────────────────────────┐
│ Course Name               [🏷 Kurs/Club]    │  card-header
├─────────────────────────────────────────────┤
│ 📅 Mo, 14.07. 18:30 Uhr – Fr, 18.07.       │
│ 🔁 Wöchentlich                              │  card-body
│ 📆 Mo, 07.07.  Mo, 14.07.  Mo, 21.07. +2   │
│ 👤 Instructor Name (or avatar photo)        │
│ Description text…                           │
├─────────────────────────────────────────────┤
│ 👥 6 / 10  ▓▓▓▓▓▓░░░░    ✅ Verfügbar      │  card-footer
│ [ 👤+ Jetzt anmelden          ] (btn-primary)│  (or disabled when booked out)
└─────────────────────────────────────────────┘
```

All icons are inline Bootstrap Icons SVGs (`width/height="11–14"`, `fill="currentColor"`). No icon font or external asset needed.

---

## Responsive grid

The grid uses Bootstrap 5's `row-cols-*` utility classes — no custom CSS needed:

```html
<div class="row row-cols-1 row-cols-sm-2 row-cols-lg-3 row-cols-xl-4 g-4 align-items-stretch">
```

| Breakpoint | Min-width | Columns |
|---|---|---|
| xs (default) | — | 1 |
| sm | 576 px | 2 |
| lg | 992 px | 3 |
| xl | 1200 px | 4 |

`align-items-stretch` combined with `h-100` on the card ensures all cards in a row share the same height regardless of content length.

---

## Register button

Added to `card-footer` below the seats/availability row. State depends on `course.isBookedOut`:

| State | Element | Classes |
|---|---|---|
| Available | `<a href="#">` | `btn btn-primary w-100` |
| Booked out | `<a href="#">` | `btn btn-secondary w-100 disabled` + `aria-disabled="true" tabindex="-1"` |

An `<a>` element has no native `disabled` state, so the Bootstrap `.disabled` class plus `aria-disabled` and `tabindex="-1"` are required for both visual and accessible disabled behaviour. The `href="#"` is a placeholder — replace with the actual registration URL when available.

---

## CSS inclusion

`kurstool.css` is injected via `<f:asset.css>` in `Index.html`:

```html
<f:asset.css identifier="ext-kurstool"
             href="{f:uri.resource(path: 'Css/kurstool.css', extensionName: 'kurstool')}" />
```

`f:asset.css` deduplicates by `identifier` (safe to render the plugin multiple times on one page) and places the `<link>` in `<head>` regardless of where in the page the ViewHelper is called.
