# Courses Preview in Backend Form (fieldWizard)

## Goal

Display a live course list directly **below** the **Category** selector in the TYPO3 content element edit form, so editors can verify which courses will appear on the frontend without leaving the backend. The panel adapts automatically to the TYPO3 backend light/dark theme.

---

## What was built

### `Classes/Backend/Form/FieldWizard/CoursePreviewFieldWizard.php`

A TYPO3 form engine `fieldWizard` node that:
- Reads the currently selected `categoryId` from `$this->data['parameterArray']['itemFormElValue']`
- Reads `locationId` from the saved FlexForm data (`pi_flexform.data.sDEF.lDEF.settings.locationId.vDEF`)
- Resolves API credentials from the page's site settings via `SiteFinder`
- Calls `ApiService::getCourses()` (cached)
- Renders a flexbox-based course list showing: **name**, **startsAt**, **type** (Club/Course), **seats** (current/max), **status** (available/booked out)

---

## Design decisions

### `fieldWizard` instead of `fieldInformation`

The initial implementation used `fieldInformation`. Two problems were discovered:

1. **Wrong position** — `fieldInformation` renders *above* the field element. `fieldWizard` renders *below*, which is what we want.
2. **HTML allowlist** — `fieldInformation` enforces a strict tag allowlist:
   ```
   <a> <br> <div> <em> <i> <p> <strong> <span> <code>
   ```
   `<table>` and its children cause a `RuntimeException`. `fieldWizard` has no such restriction, but the flexbox `<div>` layout is kept anyway as it is more lightweight.

### `GeneralUtility::makeInstance()` instead of constructor injection

`AbstractNode` subclasses are always instantiated by `NodeFactory` as:
```php
GeneralUtility::makeInstance($class, $nodeFactory, $data)
```
Because constructor arguments are passed, TYPO3's `makeInstance()` bypasses the DI container and calls `new $class($nodeFactory, $data)` directly. Constructor injection therefore does not work here.

Services are obtained inside `render()` via `GeneralUtility::makeInstance(ApiService::class)` (no extra args), which *does* use the DI container — provided `ApiService` is declared `public: true` in `Services.yaml`.

### `scalarValue()` helper

TYPO3 FormEngine passes select field values and FlexForm `vDEF` entries as arrays in some contexts. A direct `(string)` cast on an array produces a PHP Warning. The `scalarValue()` helper unwraps arrays by taking the first element before casting.

### Theming with TYPO3 design-system CSS variables

#### Why `--bs-*` variables do NOT work for dark mode

`backend.css` defines Bootstrap dark-mode overrides under `[data-bs-theme=dark]`, but TYPO3 v14 **never sets that attribute**. Instead it sets `data-color-scheme=dark` on `<html>` (via `PageRenderer` on page load and `user-settings-manager.js` on toggle). The CSS for that attribute is only:

```css
[data-color-scheme=dark] { color-scheme: only dark }
```

This enables the CSS `light-dark()` function on all descendants. TYPO3's own `--typo3-*` design-system variables use `light-dark()` and therefore **do** adapt. The Bootstrap `[data-bs-theme=dark]` block is dead code as far as the TYPO3 backend is concerned.

#### Correct variable mapping

| Purpose | Variable |
|---|---|
| Body/bright background | `--typo3-surface-bright` |
| Alternate row bg | `--typo3-surface-container-base` |
| Header row bg | `--typo3-surface-container-high` |
| Borders | `--typo3-state-default-border-color` |
| Primary text | `--typo3-text-color-base` |
| Muted/secondary text | `--typo3-text-color-secondary` |
| Empty-state background | `--typo3-surface-container-info` |
| Empty-state border/accent | `--typo3-surface-info` |
| Club badge background | `--typo3-surface-primary` |
| Club badge text | `--typo3-surface-primary-text` |
| Course badge background | `--typo3-surface-secondary` |
| Course badge text | `--typo3-surface-secondary-text` |
| Available badge background | `--typo3-surface-success` |
| Available badge text | `--typo3-surface-success-text` |
| Booked-out badge background | `--typo3-surface-danger` |
| Booked-out badge text | `--typo3-surface-danger-text` |

---

## Changes

| File | Change |
|---|---|
| `Classes/Backend/Form/FieldWizard/CoursePreviewFieldWizard.php` | New — `fieldWizard` `AbstractNode` implementation |
| `Classes/Backend/Form/FieldInformation/CoursePreviewFieldInformation.php` | Superseded — can be deleted |
| `ext_localconf.php` | `nodeRegistry[1745000001]` updated to point to `CoursePreviewFieldWizard` |
| `Configuration/Services.yaml` | `ApiService` declared `public: true` |
| `Configuration/FlexForms/CoursePlugin.xml` | `<fieldInformation>` replaced with `<fieldWizard>` on `settings.categoryId` |
| `Classes/Domain/Dto/Course.php` | Added `isClub: bool` field |
| `server/src/controllers/public.ts` | Added `isClub: true` to the Prisma `select` in `coursesHandler` |

---

## Page Module Preview Renderer

### Goal

Show a selection breadcrumb (e.g. **Tanzschule Nord / Erwachsene / Salsa**) below the plugin headline in the Web > Page module, so editors immediately see which course category is configured without opening the edit form.

### `Classes/Backend/Preview/CoursePluginPreviewRenderer.php`

Extends `StandardContentPreviewRenderer`. Constructor-injects `ApiService` and `SiteFinder`.

Overrides `renderPageModulePreviewContent()`:
1. Reads `pi_flexform` from the raw tt_content record via `$item->getRecord()->getRawRecord()?->toArray()`
2. Parses it with `FlexFormService::convertFlexFormContentToArray()`
3. For **hierarchy** mode: resolves location, target, and category names from `ApiService::getBootstrapData()`
4. For **flat** mode: reads `flatTargetName` and `flatCategoryName` directly from FlexForm settings
5. Appends a small muted breadcrumb `<div>` below the default preview content

### Why constructor injection works here

`GridColumnItem` resolves the renderer class via `GeneralUtility::makeInstance($rendererClass)` with **no extra constructor arguments**, so `makeInstance()` uses the DI container — constructor injection works normally. The class must be declared `public: true` in `Services.yaml`.

This is the opposite of `AbstractNode` subclasses (fieldWizard/fieldInformation), where `NodeFactory` passes `$nodeFactory` and `$data` as constructor args, bypassing the container.

### Additional changes

| File | Change |
|---|---|
| `Classes/Backend/Preview/CoursePluginPreviewRenderer.php` | New — page module preview renderer |
| `Configuration/TCA/Overrides/tt_content.php` | `$GLOBALS['TCA']['tt_content']['types'][$pluginIdentifier]['previewRenderer']` set to `CoursePluginPreviewRenderer::class` |
| `Configuration/Services.yaml` | `CoursePluginPreviewRenderer` declared `public: true` |

---

## Activation

1. `ddev exec vendor/bin/typo3 cache:flush`
2. Restart the Node server (picks up `isClub` in the API response)
3. Edit a content element → select Location → Target → Category → the course preview renders below the category dropdown
4. Web > Page module → the content element tile shows the selected Location / Target / Category breadcrumb
