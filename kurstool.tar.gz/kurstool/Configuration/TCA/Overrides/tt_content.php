<?php

declare(strict_types=1);

use TYPO3\CMS\Core\Utility\ExtensionManagementUtility;
use TYPO3\CMS\Extbase\Utility\ExtensionUtility;

defined('TYPO3') or die;

$pluginIdentifier = ExtensionUtility::registerPlugin(
    'Kurstool',
    'Courses',
    'LLL:EXT:kurstool/Resources/Private/Language/locallang_db.xlf:plugin.courses.title',
    'EXT:kurstool/Resources/Public/Icons/Extension.svg',
    'kurstool',
    'LLL:EXT:kurstool/Resources/Private/Language/locallang_db.xlf:plugin.courses.description',
);

ExtensionManagementUtility::addPiFlexFormValue(
    '*',
    'FILE:EXT:kurstool/Configuration/FlexForms/CoursePlugin.xml',
    $pluginIdentifier
);

ExtensionManagementUtility::addToAllTCAtypes(
    'tt_content',
    '--div--;LLL:EXT:frontend/Resources/Private/Language/locallang_ttc.xlf:tabs.plugin, pi_flexform',
    $pluginIdentifier,
    'after:palette:headers'
);

$GLOBALS['TCA']['tt_content']['columns']['CType']['config']['itemGroups']['kurstool']
    = 'LLL:EXT:kurstool/Resources/Private/Language/locallang_db.xlf:group.kurstool';

$GLOBALS['TCA']['tt_content']['types'][$pluginIdentifier]['previewRenderer']
    = \Taketool\Kurstool\Backend\Preview\CoursePluginPreviewRenderer::class;
