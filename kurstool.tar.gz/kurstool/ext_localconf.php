<?php

declare(strict_types=1);

use Taketool\Kurstool\Backend\Form\FieldWizard\CoursePreviewFieldWizard;
use Taketool\Kurstool\Controller\CourseController;
use TYPO3\CMS\Core\Cache\Backend\SimpleFileBackend;
use TYPO3\CMS\Core\Cache\Frontend\VariableFrontend;
use TYPO3\CMS\Extbase\Utility\ExtensionUtility;

defined('TYPO3') or die;

(static function (): void {
    ExtensionUtility::configurePlugin(
        'Kurstool',
        'Courses',
        [CourseController::class => 'index'],
        [],
        ExtensionUtility::PLUGIN_TYPE_CONTENT_ELEMENT
    );

    $GLOBALS['TYPO3_CONF_VARS']['SYS']['formEngine']['nodeRegistry'][1745000001] = [
        'nodeName' => 'kurstoolCoursePreview',
        'priority' => 40,
        'class' => CoursePreviewFieldWizard::class,
    ];

    if (empty($GLOBALS['TYPO3_CONF_VARS']['SYS']['caching']['cacheConfigurations']['kurstool_api'])) {
        $GLOBALS['TYPO3_CONF_VARS']['SYS']['caching']['cacheConfigurations']['kurstool_api'] = [
            'frontend' => VariableFrontend::class,
            'backend' => SimpleFileBackend::class,
            'groups' => ['all', 'pages'],
            'options' => [
                'defaultLifetime' => 3600,
            ],
        ];
    }
})();
