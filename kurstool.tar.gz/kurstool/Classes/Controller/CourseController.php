<?php

declare(strict_types=1);

namespace Taketool\Kurstool\Controller;

use Psr\Http\Message\ResponseInterface;
use Taketool\Kurstool\Domain\Dto\BootstrapData;
use Taketool\Kurstool\Service\ApiService;
use TYPO3\CMS\Extbase\Mvc\Controller\ActionController;

final class CourseController extends ActionController
{
    public function __construct(
        private readonly ApiService $apiService,
    ) {}

    public function indexAction(): ResponseInterface
    {
        $site = $this->request->getAttribute('site');
        $siteSettings = $site->getSettings();

        $useDevApi = (bool)$siteSettings->get('kurstool.useDevApi', false);
        $apiDomain = $useDevApi
            ? (string)$siteSettings->get('kurstool.devApiDomain', 'http://host.docker.internal:8000')
            : (string)$siteSettings->get('kurstool.apiDomain', 'https://gui4.kurstool.de');
        $apiKey = $useDevApi
            ? (string)$siteSettings->get('kurstool.devApiKey', '')
            : (string)$siteSettings->get('kurstool.apiKey', '');
        $cacheTtl = (int)$siteSettings->get('kurstool.cacheTtl', 3600);

        $selectionMode = (string)($this->settings['selectionMode'] ?? 'hierarchy');
        $locationId = (string)($this->settings['locationId'] ?? '');
        $categoryId = (string)($this->settings['categoryId'] ?? '');
        $flatTargetName = (string)($this->settings['flatTargetName'] ?? '');
        $flatCategoryName = (string)($this->settings['flatCategoryName'] ?? '');

        $courses = [];
        $error = null;

        try {
            $bootstrapData = $this->apiService->getBootstrapData($apiDomain, $apiKey, $cacheTtl);

            if ($selectionMode === 'flat') {
                [$categoryId, $locationId] = $this->resolveFlat(
                    $bootstrapData,
                    $flatTargetName,
                    $flatCategoryName
                );
            }

            if ($categoryId !== '' && $locationId !== '') {
                $courses = $this->apiService->getCourses(
                    $apiDomain,
                    $apiKey,
                    $categoryId,
                    $locationId,
                    $cacheTtl
                );
            }

        } catch (\Throwable $e) {
            $error = $e->getMessage();
        }

        $cObj = $this->request->getAttribute('currentContentObject');
        $contentData = $cObj?->data ?? [];

        $this->view->assignMultiple([
            'courses' => $courses,
            'error' => $error,
            'header' => (string)($contentData['header'] ?? ''),
            'headerLayout' => (int)($contentData['header_layout'] ?? 2),
            'subheader' => (string)($contentData['subheader'] ?? ''),
        ]);

        return $this->htmlResponse();
    }

    /**
     * @return array{0: string, 1: string} [categoryId, locationId]
     */
    private function resolveFlat(
        BootstrapData $bootstrapData,
        string $flatTargetName,
        string $flatCategoryName,
    ): array {
        $matchedTarget = null;
        foreach ($bootstrapData->targets as $target) {
            if ($target->name === $flatTargetName) {
                $matchedTarget = $target;
                break;
            }
        }

        if ($matchedTarget === null) {
            return ['', ''];
        }

        foreach ($bootstrapData->categories as $category) {
            if ($category->targetId === $matchedTarget->id && $category->name === $flatCategoryName) {
                return [$category->id, $matchedTarget->locationId];
            }
        }

        return ['', ''];
    }
}
