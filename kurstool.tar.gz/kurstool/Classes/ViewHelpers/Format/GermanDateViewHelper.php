<?php

declare(strict_types=1);

namespace Taketool\Kurstool\ViewHelpers\Format;

use TYPO3Fluid\Fluid\Core\ViewHelper\AbstractViewHelper;

/**
 * Formats an ISO date string as German date with weekday abbreviation.
 * Examples: "Mo, 14.07. 18:30 Uhr" / "Mo, 14.07.2026 18:30 Uhr" / "Mo, 14.07."
 */
final class GermanDateViewHelper extends AbstractViewHelper
{
    protected $escapeOutput = false;

    public function initializeArguments(): void
    {
        $this->registerArgument('date', 'string', 'ISO date string', true);
        $this->registerArgument('showTime', 'bool', 'Include time', false, true);
        $this->registerArgument('timeOnly', 'bool', 'Show time only, no date', false, false);
    }

    public function render(): string
    {
        $dateStr = (string)($this->arguments['date'] ?? '');
        if ($dateStr === '') {
            return '';
        }
        try {
            $dt = new \DateTimeImmutable($dateStr);
            $hasTime = $dt->format('H:i') !== '00:00';

            if ((bool)$this->arguments['timeOnly']) {
                return $hasTime ? $dt->format('H:i') . ' Uhr' : '';
            }

            $day = ['Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa', 'So'][(int)$dt->format('N') - 1];
            $sameYear = $dt->format('Y') === date('Y');
            $datePart = $sameYear ? $dt->format('d.m.') : $dt->format('d.m.Y');

            if ((bool)$this->arguments['showTime'] && $hasTime) {
                return $day . ', ' . $datePart . ' ' . $dt->format('H:i') . ' Uhr';
            }

            return $day . ', ' . $datePart;
        } catch (\Throwable) {
            return htmlspecialchars($dateStr);
        }
    }
}
