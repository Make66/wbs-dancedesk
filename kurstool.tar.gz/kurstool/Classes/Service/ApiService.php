<?php

declare(strict_types=1);

namespace Taketool\Kurstool\Service;

use Taketool\Kurstool\Domain\Dto\BootstrapData;
use Taketool\Kurstool\Domain\Dto\Course;
use TYPO3\CMS\Core\Cache\CacheManager;
use TYPO3\CMS\Core\Cache\Frontend\FrontendInterface;
use TYPO3\CMS\Core\Http\RequestFactory;

final class ApiService
{
    /*
    private const testJson = '{
"customer": {
    "id": "afac14e6-a507-419b-ad0b-c1e3ada7d6d1",
    "name": "DanceSchool Flipn Bit",
    "email": "info@dancedesk.de",
    "website": "https://www.wbscodingschool.com",
    "logoUrl": "http://localhost:8000/assets/images/flipnbit2_xs.png",
    "primary": "#B80000",
    "secondary": "#5F0000",
    "tertiary": "#565656",
    "quaternary": "#BABABA",
    "street": "123 Main St",
    "city": "Any town",
    "zipCode": "12345",
    "longitude": 0,
    "latitude": 0itemsProcFunc
},
"locations": [
        {
            "id": "9a1e23fc-d32b-423d-8e71-d91ff24a8a44",
            "name": "Achern",
            "description": "",
            "imageUrl": "/assets/images/no-profile-picture.svg",
            "street": "123 Main St",
            "city": "Anytown",
            "zipCode": "12345",
            "state": "State",
            "longitude": 0,
            "latitude": 0,
            "targets": [
                {
                    "id": "7fbc042b-e767-43ed-adac-b274033e70a5",
                    "name": "Alles weitere (Einzelne Tanzarten und Fitness)",
                    "description": "",
                    "icon": "",
                    "color": [
                    "#5e8b83",
                    "#fff"
                ],
                    "locationId": "9a1e23fc-d32b-423d-8e71-d91ff24a8a44",
                    "setSeqCategory": [],
                    "categories": [
                        {
                            "id": "27b8d4aa-0df5-42a1-bd78-2c66921e41ed",
                            "name": "Latino Social Club",
                            "description": "",
                            "icon": "",
                            "color": [
                            "#86198F",
                            "#fff"
                        ],
                            "targetId": "7fbc042b-e767-43ed-adac-b274033e70a5",
                            "setSeqCourse": []
                        },
                        {
                            "id": "28716ff2-4b51-43b9-968a-99c5a6cc255c",
                            "name": "Line Dance",
                            "description": "",
                            "icon": "",
                            "color": [
                            "#98980c",
                            "#fff"
                        ],
                            "targetId": "7fbc042b-e767-43ed-adac-b274033e70a5",
                            "setSeqCourse": []
                        },
                        {
                            "id": "33acb453-71df-46bf-935f-ffaaec33b94a",
                            "name": "Salsa",
                            "description": "",
                            "icon": "",
                            "color": [
                            "#333333",
                            "#fff"
                        ],
                            "targetId": "7fbc042b-e767-43ed-adac-b274033e70a5",
                            "setSeqCourse": []
                        },
                        {
                            "id": "8c5dfea7-530b-4101-a870-2f8b0d3ea178",
                            "name": "Tanzfit",
                            "description": "",
                            "icon": "",
                            "color": [
                            "#16168e",
                            "#fff"
                        ],
                            "targetId": "7fbc042b-e767-43ed-adac-b274033e70a5",
                            "setSeqCourse": []
                        },
                        {
                            "id": "a2245417-bc7d-45e0-a038-b4f26dd87d55",
                            "name": "Zumba",
                            "description": "",
                            "icon": "",
                            "color": [
                            "#DB2777",
                            "#fff"
                        ],
                            "targetId": "7fbc042b-e767-43ed-adac-b274033e70a5",
                            "setSeqCourse": []
                        }
                    ]
                },
                {
                    "id": "f27d682d-ce57-4503-a65c-93189d8eae45",
                    "name": "Jugend",
                    "description": "",
                    "icon": "",
                    "color": [
                    "#16168e",
                    "#fff"
                ],
                    "locationId": "9a1e23fc-d32b-423d-8e71-d91ff24a8a44",
                    "setSeqCategory": [],
                    "categories": [
                        {
                            "id": "fa33be06-0c7e-448c-a91d-3923fee1f38d",
                            "name": "Grundkurs Jugend",
                            "description": "",
                            "icon": "",
                            "color": [
                            "#1F7A55",
                            "#fff"
                        ],
                            "targetId": "f27d682d-ce57-4503-a65c-93189d8eae45",
                            "setSeqCourse": []
                        }
                    ]
                },
                {
                    "id": "f6284c6e-0eea-4781-8de5-e91d53b07765",
                    "name": "Kinder",
                    "description": "",
                    "icon": "",
                    "color": [
                    "#E7180B",
                    "#fff"
                ],
                    "locationId": "9a1e23fc-d32b-423d-8e71-d91ff24a8a44",
                    "setSeqCategory": [],
                    "categories": [
                        {
                            "id": "f71f0c66-76dc-4d84-938d-cd9292e65141",
                            "name": "Kids 3-5 Jahre",
                            "description": "",
                            "icon": "",
                            "color": [
                            "#800000",
                            "#fff"
                        ],
                            "targetId": "f6284c6e-0eea-4781-8de5-e91d53b07765",
                            "setSeqCourse": []
                        },
                        {
                            "id": "23d4ff0a-3f62-4fe2-966c-3871b61f42c4",
                            "name": "Kids 5 und 6 Jahre",
                            "description": "",
                            "icon": "",
                            "color": [
                            "#D0872E",
                            "#fff"
                        ],
                            "targetId": "f6284c6e-0eea-4781-8de5-e91d53b07765",
                            "setSeqCourse": []
                        },
                        {
                            "id": "0599186d-e580-40fb-a127-5880982bba1a",
                            "name": "Kids 7 bis 9 Jahre",
                            "description": "",
                            "icon": "",
                            "color": [
                            "#1A7595",
                            "#fff"
                        ],
                            "targetId": "f6284c6e-0eea-4781-8de5-e91d53b07765",
                            "setSeqCourse": []
                        },
                        {
                            "id": "2d5d0e49-f83b-4177-89cf-a6de2125a771",
                            "name": "Nappy Dancer",
                            "description": "",
                            "icon": "",
                            "color": [
                            "#333333",
                            "#fff"
                        ],
                            "targetId": "f6284c6e-0eea-4781-8de5-e91d53b07765",
                            "setSeqCourse": []
                        }
                    ]
                },
                {
                    "id": "2e948fc9-d159-4ca6-95e3-631bd8a12992",
                    "name": "Paare und Singles",
                    "description": "",
                    "icon": "",
                    "color": [
                    "#98980c",
                    "#fff"
                ],
                    "locationId": "9a1e23fc-d32b-423d-8e71-d91ff24a8a44",
                    "setSeqCategory": [],
                    "categories": [
                        {
                            "id": "e850b69a-5fed-4920-811f-492a95bce86d",
                            "name": "Club (nach Grund- und Fortgeschrittenen Kurs)",
                            "description": "",
                            "icon": "",
                            "color": [
                            "#E7180B",
                            "#fff"
                        ],
                            "targetId": "2e948fc9-d159-4ca6-95e3-631bd8a12992",
                            "setSeqCourse": []
                        },
                        {
                            "id": "33fa333f-647d-40ff-a967-40bae73e0fea",
                            "name": "Grundkurs Paare",
                            "description": "",
                            "icon": "",
                            "color": [
                            "#9F0712",
                            "#fff"
                        ],
                            "targetId": "2e948fc9-d159-4ca6-95e3-631bd8a12992",
                            "setSeqCourse": []
                        }
                    ]
                }
            ]
        },
        {
            "id": "fe1af320-dcc9-46a3-b52e-122d563e0b68",
            "name": "Buehl",
            "description": "",
            "imageUrl": "/assets/images/no-profile-picture.svg",
            "street": "123 Main St",
            "city": "Anytown",
            "zipCode": "12345",
            "state": "State",
            "longitude": 0,
            "latitude": 0,
            "targets": [
                {
                    "id": "4c5b93c4-c234-42b1-a117-d010638969a1",
                    "name": "Ferienworkshops",
                    "description": "",
                    "icon": "",
                    "color": [
                    "#DB2777",
                    "#fff"
                ],
                    "locationId": "fe1af320-dcc9-46a3-b52e-122d563e0b68",
                    "setSeqCategory": [],
                    "categories": []
                },
                {
                    "id": "83e43a9c-e00b-40ed-be95-8bfe43b063fd",
                    "name": "Fitness",
                    "description": "",
                    "icon": "",
                    "color": [
                    "#1F7A55",
                    "#fff"
                ],
                    "locationId": "fe1af320-dcc9-46a3-b52e-122d563e0b68",
                    "setSeqCategory": [],
                    "categories": [
                        {
                            "id": "877247dc-d24a-45d7-94a2-21f80c40e6ae",
                            "name": "Fitness",
                            "description": "",
                            "icon": "",
                            "color": [
                            "#16168e",
                            "#fff"
                        ],
                            "targetId": "83e43a9c-e00b-40ed-be95-8bfe43b063fd",
                            "setSeqCourse": []
                        }
                    ]
                },
                {
                    "id": "a25de506-a0c4-4ba3-97e4-5f0ca41f5e48",
                    "name": "Generation+",
                    "description": "",
                    "icon": "",
                    "color": [
                    "#9F0712",
                    "#fff"
                ],
                    "locationId": "fe1af320-dcc9-46a3-b52e-122d563e0b68",
                    "setSeqCategory": [],
                    "categories": [
                        {
                            "id": "aa69b1f7-3bd3-45dd-a9c0-3302240ee5e0",
                            "name": "Gesellschaftstanz - Tanzfit",
                            "description": "",
                            "icon": "",
                            "color": [
                            "#DB2777",
                            "#fff"
                        ],
                            "targetId": "a25de506-a0c4-4ba3-97e4-5f0ca41f5e48",
                            "setSeqCourse": []
                        },
                        {
                            "id": "beae2b33-51c3-4223-8735-c16bde8a7a70",
                            "name": "Tanzfit",
                            "description": "",
                            "icon": "",
                            "color": [
                            "#5e8b83",
                            "#fff"
                        ],
                            "targetId": "a25de506-a0c4-4ba3-97e4-5f0ca41f5e48",
                            "setSeqCourse": []
                        }
                    ]
                },
                {
                    "id": "c188401a-04b2-4bca-987f-286ab9fe6e4e",
                    "name": "HipHop",
                    "description": "",
                    "icon": "",
                    "color": [
                    "#800000",
                    "#fff"
                ],
                    "locationId": "fe1af320-dcc9-46a3-b52e-122d563e0b68",
                    "setSeqCategory": [],
                    "categories": [
                        {
                            "id": "0c6f38af-a27b-4a45-af73-e74309df34ed",
                            "name": "HipHop ",
                            "description": "",
                            "icon": "",
                            "color": [
                            "#333333",
                            "#fff"
                        ],
                            "targetId": "c188401a-04b2-4bca-987f-286ab9fe6e4e",
                            "setSeqCourse": []
                        }
                    ]
                },
                {
                    "id": "6699292a-9bbb-45f6-bcc6-d5f13f294493",
                    "name": "Jugend",
                    "description": "",
                    "icon": "",
                    "color": [
                    "#333333",
                    "#fff"
                ],
                    "locationId": "fe1af320-dcc9-46a3-b52e-122d563e0b68",
                    "setSeqCategory": [],
                    "categories": [
                        {
                            "id": "c069ff15-a8d5-4d0f-8469-15f51d300ec9",
                            "name": "Grundkurs Jugend",
                            "description": "",
                            "icon": "",
                            "color": [
                            "#16168e",
                            "#fff"
                        ],
                            "targetId": "6699292a-9bbb-45f6-bcc6-d5f13f294493",
                            "setSeqCourse": []
                        },
                        {
                            "id": "691fd455-fd60-4ebe-baf1-73b80ed2ca68",
                            "name": "Weiterführende Gruppen",
                            "description": "",
                            "icon": "",
                            "color": [
                            "#5e8b83",
                            "#fff"
                        ],
                            "targetId": "6699292a-9bbb-45f6-bcc6-d5f13f294493",
                            "setSeqCourse": []
                        }
                    ]
                },
                {
                    "id": "a66097bf-bf19-4370-a7e4-3aafc9a53127",
                    "name": "Kinder",
                    "description": "",
                    "icon": "",
                    "color": [
                    "#86198F",
                    "#fff"
                ],
                    "locationId": "fe1af320-dcc9-46a3-b52e-122d563e0b68",
                    "setSeqCategory": [],
                    "categories": [
                        {
                            "id": "6859ad7c-82f3-4c9f-9469-dbd91d273a93",
                            "name": "Dance4Fans",
                            "description": "",
                            "icon": "",
                            "color": [
                            "#9F0712",
                            "#fff"
                        ],
                            "targetId": "a66097bf-bf19-4370-a7e4-3aafc9a53127",
                            "setSeqCourse": []
                        },
                        {
                            "id": "4f67179a-05db-4708-91e3-b384c05e1b67",
                            "name": "HipHop",
                            "description": "",
                            "icon": "",
                            "color": [
                            "#9f6767",
                            "#fff"
                        ],
                            "targetId": "a66097bf-bf19-4370-a7e4-3aafc9a53127",
                            "setSeqCourse": []
                        },
                        {
                            "id": "ba2d57b5-3aa7-4a70-9252-81bd8030985a",
                            "name": "Kindertanz 3-6 Jahre",
                            "description": "",
                            "icon": "",
                            "color": [
                            "#1F7A55",
                            "#fff"
                        ],
                            "targetId": "a66097bf-bf19-4370-a7e4-3aafc9a53127",
                            "setSeqCourse": []
                        },
                        {
                            "id": "ed4378d1-f405-4d3d-8e90-b2d7a182e662",
                            "name": "Mutterkind Tanzen ab 1 Jahr",
                            "description": "",
                            "icon": "",
                            "color": [
                            "#1A7595",
                            "#fff"
                        ],
                            "targetId": "a66097bf-bf19-4370-a7e4-3aafc9a53127",
                            "setSeqCourse": []
                        }
                    ]
                },
                {
                    "id": "483736f8-9cb7-4620-b2e6-76c9a8410282",
                    "name": "Paare und Singles",
                    "description": "",
                    "icon": "",
                    "color": [
                    "#D0872E",
                    "#fff"
                ],
                    "locationId": "fe1af320-dcc9-46a3-b52e-122d563e0b68",
                    "setSeqCategory": [],
                    "categories": [
                        {
                            "id": "5c6df534-1471-48a5-9bfe-9a24abf6e5c1",
                            "name": "Gleichgeschlechtliche Kurse",
                            "description": "",
                            "icon": "",
                            "color": [
                            "#DB2777",
                            "#fff"
                        ],
                            "targetId": "483736f8-9cb7-4620-b2e6-76c9a8410282",
                            "setSeqCourse": []
                        },
                        {
                            "id": "06b2aeb6-774c-4384-830c-39d5e1810dfd",
                            "name": "Hochzeits- Crashkurse",
                            "description": "",
                            "icon": "",
                            "color": [
                            "#1F7A55",
                            "#fff"
                        ],
                            "targetId": "483736f8-9cb7-4620-b2e6-76c9a8410282",
                            "setSeqCourse": []
                        },
                        {
                            "id": "2d381033-aaac-4168-94a8-3d9bb35e3eea",
                            "name": "Paare Clubs ab Bronze",
                            "description": "",
                            "icon": "",
                            "color": [
                            "#9f6767",
                            "#fff"
                        ],
                            "targetId": "483736f8-9cb7-4620-b2e6-76c9a8410282",
                            "setSeqCourse": []
                        },
                        {
                            "id": "5ffbdd7e-dd8f-4e0a-b01a-93312b4abae1",
                            "name": "Paare Fortgeschrittene",
                            "description": "",
                            "icon": "",
                            "color": [
                                "#E7180B",
                                "#fff"
                            ],
                            "targetId": "483736f8-9cb7-4620-b2e6-76c9a8410282",
                            "setSeqCourse": []
                        },
                        {
                            "id": "462d4360-803d-444d-80a8-c117656382cc",
                            "name": "Paare Grundkurs ",
                            "description": "",
                            "icon": "",
                            "color": [
                            "#9F0712",
                            "#fff"
                        ],
                            "targetId": "483736f8-9cb7-4620-b2e6-76c9a8410282",
                            "setSeqCourse": []
                        },
                        {
                            "id": "ef311c43-ce68-4d74-b949-7217d7dd000c",
                            "name": "Privatstunden",
                            "description": "",
                            "icon": "",
                            "color": [
                            "#16168e",
                            "#fff"
                        ],
                            "targetId": "483736f8-9cb7-4620-b2e6-76c9a8410282",
                            "setSeqCourse": []
                        },
                        {
                            "id": "da224feb-1ba6-49f5-8c45-5f40ded47da8",
                            "name": "Singles Grundkurs",
                            "description": "",
                            "icon": "",
                            "color": [
                            "#1A7595",
                            "#fff"
                        ],
                            "targetId": "483736f8-9cb7-4620-b2e6-76c9a8410282",
                            "setSeqCourse": []
                        }
                    ]
                },
                {
                    "id": "d8a0ecc1-e048-49ac-870c-1ab65acd9ed4",
                    "name": "Privatstunden",
                    "description": "",
                    "icon": "",
                    "color": [
                    "#9f6767",
                    "#fff"
                ],
                    "locationId": "fe1af320-dcc9-46a3-b52e-122d563e0b68",
                    "setSeqCategory": [],
                    "categories": [
                        {
                            "id": "f7ac4036-eda3-44b3-bebe-5b89b48f9785",
                            "name": "Privatstunden",
                            "description": "",
                            "icon": "",
                            "color": [
                            "#86198F",
                            "#fff"
                        ],
                            "targetId": "d8a0ecc1-e048-49ac-870c-1ab65acd9ed4",
                            "setSeqCourse": []
                        }
                    ]
                },
                {
                    "id": "047b1ea0-1e6a-40f1-a31e-32d3e76b10cc",
                    "name": "Specials",
                    "description": "",
                    "icon": "",
                    "color": [
                    "#1A7595",
                    "#fff"
                ],
                    "locationId": "fe1af320-dcc9-46a3-b52e-122d563e0b68",
                    "setSeqCategory": [],
                    "categories": [
                        {
                            "id": "640cc75c-0c01-4f70-a898-f52e9f3944dd",
                            "name": "Discofox",
                            "description": "",
                            "icon": "",
                            "color": [
                            "#1A7595",
                            "#fff"
                        ],
                            "targetId": "047b1ea0-1e6a-40f1-a31e-32d3e76b10cc",
                            "setSeqCourse": []
                        },
                        {
                            "id": "64f1222d-fc6a-402d-94ee-4eef2658632d",
                            "name": "Linedance",
                            "description": "",
                            "icon": "",
                            "color": [
                            "#333333",
                            "#fff"
                        ],
                            "targetId": "047b1ea0-1e6a-40f1-a31e-32d3e76b10cc",
                            "setSeqCourse": []
                        },
                        {
                            "id": "c0b93958-2a40-454d-9f3c-aa70e2780480",
                            "name": "Salsa",
                            "description": "",
                            "icon": "",
                            "color": [
                            "#86198F",
                            "#fff"
                        ],
                            "targetId": "047b1ea0-1e6a-40f1-a31e-32d3e76b10cc",
                            "setSeqCourse": []
                        },
                        {
                            "id": "3d5ce4db-e6fe-40ad-abda-cda508cef27f",
                            "name": "West Coast Swing",
                            "description": "",
                            "icon": "",
                            "color": [
                            "#D0872E",
                            "#fff"
                        ],
                            "targetId": "047b1ea0-1e6a-40f1-a31e-32d3e76b10cc",
                            "setSeqCourse": []
                        }
                    ]
                }
            ]
        }
    ]
}';
    */
    private const CACHE_TAG_BOOTSTRAP = 'kurstool_bootstrap';
    private const CACHE_TAG_COURSES = 'kurstool_courses';

    private FrontendInterface $cache;

    public function __construct(
        private readonly RequestFactory $requestFactory,
        CacheManager $cacheManager,
    ) {
        $this->cache = $cacheManager->getCache('kurstool_api');
    }

    public function getBootstrapData(string $apiDomain, string $apiKey, int $cacheTtl): BootstrapData
    {
        $cacheIdentifier = $this->buildCacheIdentifier('bootstrap', $apiDomain);

        $cached = $this->cache->get($cacheIdentifier);
        if ($cached instanceof BootstrapData) {
            return $cached;
        }

        $response = $this->requestFactory->request(
            rtrim($apiDomain, '/') . '/api/public/bootstrap',
            'GET',
            ['headers' => ['X-API-Key' => $apiKey]]
        );

        $data = json_decode(
            $response->getBody()->getContents(),
            true,
            512,
            JSON_THROW_ON_ERROR
        );
        $bootstrapData = BootstrapData::fromArray($data);

        $this->cache->set($cacheIdentifier, $bootstrapData, [self::CACHE_TAG_BOOTSTRAP], $cacheTtl);

        return $bootstrapData;
    }

    /**
     * @return Course[]
     */
    public function getCourses(
        string $apiDomain,
        string $apiKey,
        string $categoryId,
        string $locationId,
        int $cacheTtl,
    ): array {
        $cacheIdentifier = $this->buildCacheIdentifier('courses', $apiDomain, $categoryId, $locationId);

        $cached = $this->cache->get($cacheIdentifier);
        if (is_array($cached)) {
            return $cached;
        }

        $uri = rtrim($apiDomain, '/') . '/api/public/courses'
            . '?categoryId=' . urlencode($categoryId)
            . '&locationId=' . urlencode($locationId);

        $response = $this->requestFactory->request(
            $uri,
            'GET',
            ['headers' => ['X-API-Key' => $apiKey]]
        );

        $data = json_decode(
            $response->getBody()->getContents(),
            true,
            512,
            JSON_THROW_ON_ERROR
        );
        $courses = array_map(
            static fn(array $c) => Course::fromArray($c),
            $data['courses'] ?? $data
        );

        $this->cache->set($cacheIdentifier, $courses, [self::CACHE_TAG_COURSES], $cacheTtl);

        return $courses;
    }

    private function buildCacheIdentifier(string ...$parts): string
    {
        return implode('_', array_map(
            static fn(string $p) => preg_replace('/[^a-zA-Z0-9_\-]/', '_', $p),
            $parts
        ));
    }
}
