<?php

declare(strict_types=1);

namespace Taketool\Kurstool\Backend\Preview;

use Taketool\Kurstool\Service\ApiService;
use TYPO3\CMS\Backend\Preview\StandardContentPreviewRenderer;
use TYPO3\CMS\Backend\View\BackendLayout\Grid\GridColumnItem;
use TYPO3\CMS\Core\Site\SiteFinder;
use TYPO3\CMS\Core\Utility\GeneralUtility;

final class CoursePluginPreviewRenderer extends StandardContentPreviewRenderer
{
    public function __construct(
        private readonly ApiService $apiService,
        private readonly SiteFinder $siteFinder,
    ) {
        // AbstractNode subclasses need this pattern; StandardContentPreviewRenderer has empty __construct
    }

    public function renderPageModulePreviewContent(GridColumnItem $item): string
    {
        $base = parent::renderPageModulePreviewContent($item);

        try {
            $row = $item->getRecord()->getRawRecord()?->toArray() ?? [];
            $flexFormXml = $row['pi_flexform'] ?? '';
            if ($flexFormXml === '') {
                return $base;
            }

            /** @var \TYPO3\CMS\Core\Service\FlexFormService $flexFormService */
            $flexFormService = GeneralUtility::makeInstance(\TYPO3\CMS\Core\Service\FlexFormService::class);
            $settings = $flexFormService->convertFlexFormContentToArray($flexFormXml)['settings'] ?? [];

            $selectionMode = $settings['selectionMode'] ?? 'hierarchy';
            $pid = (int)($row['pid'] ?? 0);

            $breadcrumb = $selectionMode === 'flat'
                ? $this->flatBreadcrumb($settings)
                : $this->hierarchyBreadcrumb($settings, $pid);

            if ($breadcrumb === '') {
                return $base;
            }

            return $base . '<div style="margin-top:4px;font-size:11px;color:var(--typo3-text-color-secondary)">'
                . $breadcrumb
                . '</div>';
        } catch (\Throwable) {
            return $base;
        }
    }

    private function hierarchyBreadcrumb(array $settings, int $pid): string
    {
        $categoryId = (string)($settings['categoryId'] ?? '');
        if ($categoryId === '') {
            return '';
        }

        try {
            $site = $this->siteFinder->getSiteByPageId($pid);
            $siteSettings = $site->getSettings();

            $useDevApi = (bool)$siteSettings->get('kurstool.useDevApi', false);
            $apiDomain = $useDevApi
                ? (string)$siteSettings->get('kurstool.devApiDomain', 'http://host.docker.internal:8000')
                : (string)$siteSettings->get('kurstool.apiDomain', 'https://gui4.kurstool.de');
            $apiKey = $useDevApi
                ? (string)$siteSettings->get('kurstool.devApiKey', '')
                : (string)$siteSettings->get('kurstool.apiKey', '');
            $cacheTtl  = (int)$siteSettings->get('kurstool.cacheTtl', 3600);

            $bootstrap = $this->apiService->getBootstrapData($apiDomain, $apiKey, $cacheTtl);

            $locationId = (string)($settings['locationId'] ?? '');
            $targetId   = (string)($settings['targetId'] ?? '');

            $locationName = '';
            foreach ($bootstrap->locations as $loc) {
                if ($loc->id === $locationId) {
                    $locationName = $loc->name;
                    break;
                }
            }

            $targetName = '';
            foreach ($bootstrap->targets as $target) {
                if ($target->id === $targetId) {
                    $targetName = $target->name;
                    break;
                }
            }

            $categoryName = '';
            foreach ($bootstrap->categories as $cat) {
                if ($cat->id === $categoryId) {
                    $categoryName = $cat->name;
                    break;
                }
            }

            $parts = array_filter([$locationName, $targetName, $categoryName]);
            return implode(' / ', array_map('htmlspecialchars', $parts));
        } catch (\Throwable) {
            return '';
        }
    }

    private function flatBreadcrumb(array $settings): string
    {
        $targetName   = (string)($settings['flatTargetName'] ?? '');
        $categoryName = (string)($settings['flatCategoryName'] ?? '');

        $parts = array_filter([$targetName, $categoryName]);
        return implode(' / ', array_map('htmlspecialchars', $parts));
    }
}
