<?php

declare(strict_types=1);

namespace Taketool\Kurstool\Backend;

use Taketool\Kurstool\Domain\Dto\BootstrapData;
use Taketool\Kurstool\Service\ApiService;
use TYPO3\CMS\Core\Site\SiteFinder;

final class FlexFormItemsProcFunc
{
    public function __construct(
        private readonly ApiService $apiService,
        private readonly SiteFinder $siteFinder,
    ) {}

    public function locationItems(array &$config): void
    {
        $bootstrapData = $this->fetchBootstrapData($config);
        if ($bootstrapData === null) {
            return;
        }

        $config['items'][] = ['label' => '– All locations –', 'value' => ''];
        foreach ($bootstrapData->locations as $location) {
            $config['items'][] = ['label' => $location->name, 'value' => $location->id];
        }
    }

    public function targetItems(array &$config): void
    {
        $bootstrapData = $this->fetchBootstrapData($config);
        if ($bootstrapData === null) {
            return;
        }

        $locationId = $this->getFlexFormValue($config, 'settings.locationId');

        $config['items'][] = ['label' => '– Select target –', 'value' => ''];
        foreach ($bootstrapData->targets as $target) {
            if ($locationId === '' || $target->locationId === $locationId) {
                $config['items'][] = ['label' => $target->name, 'value' => $target->id];
            }
        }
    }

    public function categoryItems(array &$config): void
    {
        $bootstrapData = $this->fetchBootstrapData($config);
        if ($bootstrapData === null) {
            return;
        }

        $targetId = $this->getFlexFormValue($config, 'settings.targetId');

        $config['items'][] = ['label' => '– Select category –', 'value' => ''];
        foreach ($bootstrapData->categories as $category) {
            if ($targetId === '' || $category->targetId === $targetId) {
                $config['items'][] = ['label' => $category->name, 'value' => $category->id];
            }
        }
    }

    public function flatTargetItems(array &$config): void
    {
        $bootstrapData = $this->fetchBootstrapData($config);
        if ($bootstrapData === null) {
            return;
        }

        $config['items'][] = ['label' => '– Select target –', 'value' => ''];
        $seen = [];
        foreach ($bootstrapData->targets as $target) {
            if (!in_array($target->name, $seen, true)) {
                $seen[] = $target->name;
                $config['items'][] = ['label' => $target->name, 'value' => $target->name];
            }
        }
    }

    public function flatCategoryItems(array &$config): void
    {
        $bootstrapData = $this->fetchBootstrapData($config);
        if ($bootstrapData === null) {
            return;
        }

        $flatTargetName = $this->getFlexFormValue($config, 'settings.flatTargetName');

        $matchingTargetIds = [];
        foreach ($bootstrapData->targets as $target) {
            if ($flatTargetName === '' || $target->name === $flatTargetName) {
                $matchingTargetIds[] = $target->id;
            }
        }

        $config['items'][] = ['label' => '– Select category –', 'value' => ''];
        $seen = [];
        foreach ($bootstrapData->categories as $category) {
            if (in_array($category->targetId, $matchingTargetIds, true) && !in_array($category->name, $seen, true)) {
                $seen[] = $category->name;
                $config['items'][] = ['label' => $category->name, 'value' => $category->name];
            }
        }
    }

    private function fetchBootstrapData(array $config): ?BootstrapData
    {
        try {
            $pid = (int)($config['flexParentDatabaseRow']['pid'] ?? 0);
            $site = $this->siteFinder->getSiteByPageId($pid);
            $siteSettings = $site->getSettings();

            $apiDomain = (string)$siteSettings->get('kurstool.apiDomain', 'https://gui4.kurstool.de');
            $apiKey = (string)$siteSettings->get('kurstool.apiKey', '');
            $cacheTtl = (int)$siteSettings->get('kurstool.cacheTtl', 3600);

            return $this->apiService->getBootstrapData($apiDomain, $apiKey, $cacheTtl);
        } catch (\Throwable) {
            return null;
        }
    }

    private function getFlexFormValue(array $config, string $fieldName): string
    {
        return (string)($config['flexParentDatabaseRow']['pi_flexform']['data']['sDEF']['lDEF'][$fieldName]['vDEF'] ?? '');
    }
}
