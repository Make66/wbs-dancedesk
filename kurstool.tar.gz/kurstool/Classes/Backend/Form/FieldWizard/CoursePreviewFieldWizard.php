<?php

declare(strict_types=1);

namespace Taketool\Kurstool\Backend\Form\FieldWizard;

use Taketool\Kurstool\Service\ApiService;
use TYPO3\CMS\Backend\Form\AbstractNode;
use TYPO3\CMS\Core\Site\SiteFinder;
use TYPO3\CMS\Core\Utility\GeneralUtility;

final class CoursePreviewFieldWizard extends AbstractNode
{
    public function render(): array
    {
        $result = $this->initializeResultArray();

        try {
            $categoryId = $this->scalarValue($this->data['parameterArray']['itemFormElValue'] ?? '');
            if ($categoryId === '') {
                return $result;
            }

            $locationId = $this->scalarValue(
                $this->data['databaseRow']['pi_flexform']['data']['sDEF']['lDEF']['settings.locationId']['vDEF'] ?? ''
            );

            $pid = (int)($this->data['databaseRow']['pid'] ?? 0);

            /** @var SiteFinder $siteFinder */
            $siteFinder = GeneralUtility::makeInstance(SiteFinder::class);
            $site = $siteFinder->getSiteByPageId($pid);
            $siteSettings = $site->getSettings();

            $apiDomain = (string)$siteSettings->get('kurstool.apiDomain', 'https://gui4.kurstool.de');
            $apiKey    = (string)$siteSettings->get('kurstool.apiKey', '');
            $cacheTtl  = (int)$siteSettings->get('kurstool.cacheTtl', 3600);

            /** @var ApiService $apiService */
            $apiService = GeneralUtility::makeInstance(ApiService::class);
            $courses = $apiService->getCourses($apiDomain, $apiKey, $categoryId, $locationId, $cacheTtl);

            $result['html'] = $this->renderPreview($courses);
        } catch (\Throwable) {
            $result['html'] = '';
        }

        return $result;
    }

    private function scalarValue(mixed $value): string
    {
        return is_array($value) ? (string)($value[0] ?? '') : (string)$value;
    }

    /**
     * @param \Taketool\Kurstool\Domain\Dto\Course[] $courses
     */
    private function renderPreview(array $courses): string
    {
        $count = count($courses);

        if ($count === 0) {
            return '<div style="margin-top:6px;padding:6px 10px;font-size:12px;'
                . 'background:var(--typo3-surface-container-info);color:var(--typo3-text-color-base);'
                . 'border-left:3px solid var(--typo3-surface-info);border-radius:0 3px 3px 0">'
                . '<strong>0</strong> courses in this category.'
                . '</div>';
        }

        $base = 'font-size:12px;padding:4px 8px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;';

        $headStyle = $base
            . 'font-weight:700;font-size:11px;text-transform:uppercase;letter-spacing:.04em;'
            . 'color:var(--typo3-text-color-secondary);';

        $border = '1px solid var(--typo3-state-default-border-color)';

        $header = '<div style="display:flex;'
            . 'background:var(--typo3-surface-container-high);'
            . 'border:' . $border . ';border-bottom:none;border-radius:4px 4px 0 0">'
            . '<span style="' . $headStyle . 'flex:0 0 40%">Name</span>'
            . '<span style="' . $headStyle . 'flex:0 0 18%">Starts at</span>'
            . '<span style="' . $headStyle . 'flex:0 0 12%">Type</span>'
            . '<span style="' . $headStyle . 'flex:0 0 12%">Seats</span>'
            . '<span style="' . $headStyle . 'flex:0 0 18%">Status</span>'
            . '</div>';

        $rows = '';
        $last = $count - 1;
        foreach ($courses as $i => $course) {
            $startsAt = '–';
            if ($course->startsAt !== '') {
                $dt = new \DateTimeImmutable($course->startsAt);
                $day = ['Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa', 'So'][(int)$dt->format('N') - 1];
                $dateFormat = $dt->format('Y') === date('Y') ? 'd.m.' : 'd.m.Y';
                $startsAt = $day . ' ' . $dt->format($dateFormat . ' H:i');
            }

            $typeBadge = $this->badge(
                $course->isClub ? 'Club' : 'Course',
                $course->isClub ? 'var(--typo3-surface-primary)' : 'var(--typo3-surface-secondary)',
                $course->isClub ? 'var(--typo3-surface-primary-text)' : 'var(--typo3-surface-secondary-text)'
            );

            $statusBadge = $this->badge(
                $course->isBookedOut ? 'booked out' : 'available',
                $course->isBookedOut ? 'var(--typo3-surface-danger)' : 'var(--typo3-surface-success)',
                $course->isBookedOut ? 'var(--typo3-surface-danger-text)' : 'var(--typo3-surface-success-text)'
            );

            $seats = $course->seatsMax > 0
                ? htmlspecialchars($course->seatsCurrent . ' / ' . $course->seatsMax)
                : '–';

            $rowBg = $i % 2 === 0 ? 'var(--typo3-surface-bright)' : 'var(--typo3-surface-container-base)';
            $radius = $i === $last ? 'border-radius:0 0 4px 4px' : '';

            $rows .= '<div style="display:flex;background:' . $rowBg . ';'
                . 'border:' . $border . ';border-top:none;' . $radius . '">'
                . '<span style="' . $base . 'flex:0 0 40%;font-weight:500;color:var(--typo3-text-color-base)">'
                . htmlspecialchars($course->name)
                . '</span>'
                . '<span style="' . $base . 'flex:0 0 18%;color:var(--typo3-text-color-secondary)">'
                . htmlspecialchars($startsAt)
                . '</span>'
                . '<span style="' . $base . 'flex:0 0 12%">' . $typeBadge . '</span>'
                . '<span style="' . $base . 'flex:0 0 12%;color:var(--typo3-text-color-secondary)">' . $seats . '</span>'
                . '<span style="' . $base . 'flex:0 0 18%">' . $statusBadge . '</span>'
                . '</div>';
        }

        return '<div style="margin-top:6px">'
            . '<div style="font-size:11px;font-weight:600;color:var(--typo3-text-color-secondary);'
            . 'text-transform:uppercase;letter-spacing:.05em;margin-bottom:4px">'
            . $count . ' course' . ($count !== 1 ? 's' : '') . ' in this category'
            . '</div>'
            . $header
            . $rows
            . '</div>';
    }

    private function badge(string $label, string $bgVar, string $colorVar): string
    {
        return '<span style="display:inline-block;padding:1px 6px;border-radius:3px;'
            . 'font-size:11px;font-weight:600;color:' . $colorVar . ';background:' . $bgVar . '">'
            . $label
            . '</span>';
    }
}
