<?php

declare(strict_types=1);

namespace Taketool\Kurstool\Backend\Form\FieldInformation;

use Taketool\Kurstool\Service\ApiService;
use TYPO3\CMS\Backend\Form\AbstractNode;
use TYPO3\CMS\Core\Site\SiteFinder;
use TYPO3\CMS\Core\Utility\GeneralUtility;

final class CoursePreviewFieldInformation extends AbstractNode
{
    public function render(): array
    {
        $result = $this->initializeResultArray();

        try {
            $categoryId = $this->scalarValue($this->data['parameterArray']['itemFormElValue'] ?? '');
            if ($categoryId === '') {
                return $result;
            }

            $locationId = $this->scalarValue(
                $this->data['databaseRow']['pi_flexform']['data']['sDEF']['lDEF']['settings.locationId']['vDEF'] ?? ''
            );

            $pid = (int)($this->data['databaseRow']['pid'] ?? 0);

            /** @var SiteFinder $siteFinder */
            $siteFinder = GeneralUtility::makeInstance(SiteFinder::class);
            $site = $siteFinder->getSiteByPageId($pid);
            $siteSettings = $site->getSettings();

            $apiDomain = (string)$siteSettings->get('kurstool.apiDomain', 'https://gui4.kurstool.de');
            $apiKey = (string)$siteSettings->get('kurstool.apiKey', '');
            $cacheTtl = (int)$siteSettings->get('kurstool.cacheTtl', 3600);

            /** @var ApiService $apiService */
            $apiService = GeneralUtility::makeInstance(ApiService::class);
            $courses = $apiService->getCourses($apiDomain, $apiKey, $categoryId, $locationId, $cacheTtl);

            $result['html'] = $this->renderPreview($courses);
        } catch (\Throwable) {
            $result['html'] = '';
        }

        return $result;
    }

    private function scalarValue(mixed $value): string
    {
        if (is_array($value)) {
            return (string)($value[0] ?? '');
        }
        return (string)$value;
    }

    /**
     * @param \Taketool\Kurstool\Domain\Dto\Course[] $courses
     */
    private function renderPreview(array $courses): string
    {
        $count = count($courses);

        if ($count === 0) {
            return '<div style="margin-top:6px;padding:6px 10px;background:#e8f4fd;border-left:3px solid #007bff;font-size:12px">'
                . '<strong>0</strong> courses in this category.'
                . '</div>';
        }

        $colStyle  = 'display:inline-block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:12px;padding:3px 6px;';
        $headStyle = $colStyle . 'font-weight:700;color:#495057;font-size:11px;text-transform:uppercase;letter-spacing:.04em;';

        $header = '<div style="display:flex;background:#f8f9fa;border:1px solid #dee2e6;border-bottom:none">'
            . '<span style="' . $headStyle . 'flex:0 0 40%">Name</span>'
            . '<span style="' . $headStyle . 'flex:0 0 18%">Starts at</span>'
            . '<span style="' . $headStyle . 'flex:0 0 12%">Type</span>'
            . '<span style="' . $headStyle . 'flex:0 0 12%">Seats</span>'
            . '<span style="' . $headStyle . 'flex:0 0 18%">Status</span>'
            . '</div>';

        $rows = '';
        foreach ($courses as $i => $course) {
            $startsAt = $course->startsAt !== ''
                ? (new \DateTimeImmutable($course->startsAt))->format('d.m.Y H:i')
                : '–';

            $typeColor = $course->isClub ? '#0d6efd' : '#6c757d';
            $typeLabel = $course->isClub ? 'Club' : 'Course';
            $typeBadge = '<span style="display:inline-block;padding:1px 6px;border-radius:3px;font-size:11px;'
                . 'font-weight:600;color:#fff;background:' . $typeColor . '">' . $typeLabel . '</span>';

            $statusColor = $course->isBookedOut ? '#dc3545' : '#198754';
            $statusLabel = $course->isBookedOut ? 'booked out' : 'available';
            $statusBadge = '<span style="display:inline-block;padding:1px 6px;border-radius:3px;font-size:11px;'
                . 'font-weight:600;color:#fff;background:' . $statusColor . '">' . $statusLabel . '</span>';

            $seats = $course->seatsMax > 0
                ? htmlspecialchars($course->seatsCurrent . ' / ' . $course->seatsMax)
                : '–';

            $rowBg = $i % 2 === 0 ? '#fff' : '#f8f9fa';

            $rows .= '<div style="display:flex;background:' . $rowBg . ';border:1px solid #dee2e6;border-top:none">'
                . '<span style="' . $colStyle . 'flex:0 0 40%;font-weight:500">'
                . htmlspecialchars($course->name)
                . '</span>'
                . '<span style="' . $colStyle . 'flex:0 0 18%;color:#495057">'
                . htmlspecialchars($startsAt)
                . '</span>'
                . '<span style="' . $colStyle . 'flex:0 0 12%">' . $typeBadge . '</span>'
                . '<span style="' . $colStyle . 'flex:0 0 12%;color:#495057">' . $seats . '</span>'
                . '<span style="' . $colStyle . 'flex:0 0 18%">' . $statusBadge . '</span>'
                . '</div>';
        }

        return '<div style="margin-top:8px">'
            . '<div style="font-size:11px;font-weight:600;color:#6c757d;text-transform:uppercase;'
            . 'letter-spacing:.05em;margin-bottom:4px">'
            . $count . ' course' . ($count !== 1 ? 's' : '') . ' in this category'
            . '</div>'
            . $header
            . $rows
            . '</div>';
    }
}
