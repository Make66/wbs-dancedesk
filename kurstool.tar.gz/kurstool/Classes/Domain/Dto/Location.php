<?php

declare(strict_types=1);

namespace Taketool\Kurstool\Domain\Dto;

readonly class Location
{
    public function __construct(
        public string $id,
        public string $name,
        public string $description,
        public string $imageUrl,
        public string $street,
        public string $city,
        public string $zipCode,
        public string $state,
        public float $longitude,
        public float $latitude,
    ) {}

    public static function fromArray(array $data): self
    {
        return new self(
            id: $data['id'] ?? '',
            name: $data['name'] ?? '',
            description: $data['description'] ?? '',
            imageUrl: $data['imageUrl'] ?? '',
            street: $data['street'] ?? '',
            city: $data['city'] ?? '',
            zipCode: $data['zipCode'] ?? '',
            state: $data['state'] ?? '',
            longitude: (float)($data['longitude'] ?? 0.0),
            latitude: (float)($data['latitude'] ?? 0.0),
        );
    }
}
