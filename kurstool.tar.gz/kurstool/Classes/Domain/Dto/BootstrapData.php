<?php

declare(strict_types=1);

namespace Taketool\Kurstool\Domain\Dto;

readonly class BootstrapData
{
    /**
     * @param Location[] $locations
     * @param Target[]   $targets
     * @param Category[] $categories
     */
    public function __construct(
        public mixed $customer,
        public array $locations,
        public array $targets,
        public array $categories,
    ) {}

    public static function fromArray(array $data): self
    {
        $locations = [];
        $targets = [];
        $categories = [];

        // API returns nested structure: locations[].targets[].categories[]
        foreach ($data['locations'] ?? [] as $locationData) {
            $locations[] = Location::fromArray($locationData);
            foreach ($locationData['targets'] ?? [] as $targetData) {
                $targets[] = Target::fromArray($targetData);
                foreach ($targetData['categories'] ?? [] as $categoryData) {
                    $categories[] = Category::fromArray($categoryData);
                }
            }
        }

        // Fallback: flat top-level arrays (as per API documentation)
        if ($targets === [] && isset($data['targets'])) {
            $targets = array_map(static fn(array $t) => Target::fromArray($t), $data['targets']);
        }
        if ($categories === [] && isset($data['categories'])) {
            $categories = array_map(static fn(array $c) => Category::fromArray($c), $data['categories']);
        }

        return new self(
            customer: $data['customer'] ?? null,
            locations: $locations,
            targets: $targets,
            categories: $categories,
        );
    }
}
