<?php

declare(strict_types=1);

namespace Taketool\Kurstool\Domain\Dto;

readonly class Instructor
{
    public function __construct(
        public string $id,
        public string $name,
        public string $imageUrl,
    ) {}

    public static function fromArray(array $data): self
    {
        return new self(
            id: $data['id'] ?? '',
            name: $data['name'] ?? '',
            imageUrl: $data['imageUrl'] ?? '',
        );
    }
}
