<?php

declare(strict_types=1);

namespace Taketool\Kurstool\Domain\Dto;

readonly class Target
{
    /**
     * @param string[] $color
     * @param string[] $setSeqCategory
     */
    public function __construct(
        public string $id,
        public string $name,
        public string $description,
        public string $icon,
        public array $color,
        public string $locationId,
        public array $setSeqCategory,
    ) {}

    public static function fromArray(array $data): self
    {
        return new self(
            id: $data['id'] ?? '',
            name: $data['name'] ?? '',
            description: $data['description'] ?? '',
            icon: $data['icon'] ?? '',
            color: (array)($data['color'] ?? []),
            locationId: $data['locationId'] ?? '',
            setSeqCategory: (array)($data['setSeqCategory'] ?? []),
        );
    }
}
