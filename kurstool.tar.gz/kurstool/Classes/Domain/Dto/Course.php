<?php

declare(strict_types=1);

namespace Taketool\Kurstool\Domain\Dto;

readonly class Course
{
    /**
     * @param array<int, array{date: string, isStart: bool}> $dates
     */
    public function __construct(
        public string $id,
        public string $name,
        public string $description,
        public string $startsAt,
        public string $endsAt,
        public string $frequency,
        public array $dates,
        public int $seatsCurrent,
        public int $seatsMax,
        public bool $isBookedOut,
        public bool $isClub,
        public mixed $options,
        public string $categoryId,
        public string $locationId,
        public Instructor $instructor,
    ) {}

    public function getSeatsPercent(): int
    {
        if ($this->seatsMax <= 0) {
            return 0;
        }
        return min(100, (int)(($this->seatsCurrent / $this->seatsMax) * 100));
    }

    public static function fromArray(array $data): self
    {
        return new self(
            id: $data['id'] ?? '',
            name: $data['name'] ?? '',
            description: $data['description'] ?? '',
            startsAt: $data['startsAt'] ?? '',
            endsAt: $data['endsAt'] ?? '',
            frequency: $data['frequency'] ?? '',
            dates: (array)($data['dates'] ?? []),
            seatsCurrent: (int)($data['seatsCurrent'] ?? 0),
            seatsMax: (int)($data['seatsMax'] ?? 0),
            isBookedOut: (bool)($data['isBookedOut'] ?? false),
            isClub: (bool)($data['isClub'] ?? false),
            options: $data['options'] ?? null,
            categoryId: $data['categoryId'] ?? '',
            locationId: $data['locationId'] ?? '',
            instructor: Instructor::fromArray($data['instructor'] ?? []),
        );
    }
}
