<?php

$EM_CONF[$_EXTKEY] = [
    'title' => 'Kurstool',
    'description' => 'Include courses from Taketool Kurstool v4 in your website',
    'category' => 'plugin',
    'state' => 'stable',
    'author' => 'Martin Keller',
    'author_email' => 'martin.keller@taketool.de',
    'author_company' => 'Taketool GmbH',
    'version' => '0.0.1',
    'constraints' => [
        'depends' => [
            'typo3' => '14.0.0-14.3.99',
        ],
        'conflicts' => [],
        'suggests' => [],
    ],
];